package application;

import java.io.IOException;
import com.jfoenix.controls.JFXButton;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

 
public class ControlRocket {
	
	@FXML
	private ImageView imagen;
	
	@FXML
	private JFXButton boton;

	@FXML
	private AnchorPane view2;

	@FXML
	private AnchorPane mainview;

	public void initialize() {
		fadeIn();
	}
	
	public void closeStage() {
		Stage st = (Stage) mainview.getScene().getWindow();
		st.close();
	}

	public void openStage() {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Urano.fxml"));
		try {
			view2 = loader.load();
			Stage st = new Stage();
			st.setScene(new Scene(view2));
			st.centerOnScreen();
			st.show();
			closeStage();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void fadeIn() {
		FadeTransition fade = new FadeTransition(Duration.seconds(4), imagen);
		fade.setFromValue(0);
		fade.setToValue(1);
		fade.play();
	}
	
	public void hover() {
		boton.setStyle("-fx-background-color: green");
	}
	
	public void unHover() {
		boton.setStyle("-fx-background-color: #f1e17e");
	}
}