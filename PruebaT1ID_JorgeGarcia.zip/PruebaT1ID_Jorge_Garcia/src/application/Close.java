package application;

import com.jfoenix.controls.JFXButton;

import javafx.fxml.FXML;

public class Close {
	@FXML
	private JFXButton boton2;
	
	public void hover() {
		boton2.setStyle("-fx-background-color: red");
	}
	
	public void unHover() {
		boton2.setStyle("-fx-background-color: #f1e17e");
	}

	public void closeApp() {
		System.exit(0);
	}
	
}
