package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;

/**
 * 
 * @author JorgeGarc�a
 * @version 1.0
 * 
 *
 */

public class MainRocket extends Application {
	
	@Override
	public void start(Stage primaryStage) {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Mars.fxml"));
		try {
			AnchorPane panelLogin = loader.load();
			primaryStage.setScene(new Scene(panelLogin));
			primaryStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		launch(args);
	}
}